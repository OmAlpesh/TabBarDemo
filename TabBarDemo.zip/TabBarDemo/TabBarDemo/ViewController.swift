//
//  ViewController.swift
//  TabBarDemo
//
//  Created by alpesh patel on 2/18/16.
//  Copyright © 2016 alpesh patel. All rights reserved.
//

import UIKit


class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
        
    }

    
    
    @IBAction func BtnCollcectionTap(_ sender: AnyObject) {
        
        let collectionView = self.storyboard?.instantiateViewController(withIdentifier: "CollectionViewController") as? CollectionViewController
        
        //NavigateObj .NavigateTo(tableViewFile!, navigationViewController: navigationController!, animated: true)
        
        var VCfount : Bool = false
        
        var viewControllers: NSArray = [];
        
        viewControllers = navigationController!.viewControllers as NSArray;
        
        var indexofVC : NSInteger = 0
        
        for vc in viewControllers
        {
            if (vc as AnyObject).isKind(of: CollectionViewController.self)
            {
                indexofVC = viewControllers .index(of: vc)
                VCfount = true
                break
            }
        }
        
        if VCfount == true
        {
            navigationController! .popToViewController(viewControllers .object(at: indexofVC) as! UIViewController, animated: true)
        }
        else
        {
            navigationController! .pushViewController(collectionView!, animated: true)
        }

        
    }
    

}

